<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>测试页面</title>
		<link type="text/css" rel="stylesheet" href="http://g.tbcdn.cn/ebook/example/1.0.0/common/??base-min.css,global-min.css">
		<link type="text/css" rel="stylesheet" href="http://g.tbcdn.cn/ebook/example/1.0.0/pages/pagename/page/index-min.css">
		<script type="text/javascript" src="http://g.tbcdn.cn/kissy/k/1.4.1/seed-min.js" charset="utf-8"></script>
		<script type="text/javascript" src="http://g.tbcdn.cn/ebook/example/1.0.0/common/??package-config-min.js,base-min.js,global-min.js" charset="utf-8"></script>
		<script>ABC.config({pub:'1.0.0',path:'http://g.tbcdn.cn/ebook/example/',pageName:'pagename'});</script>
	</head>
	<body>
		<?php include('./demo/global/header.php');//引用项目公用文件路径需要注意 ?>

		<br>

		I'm a example!

		<br>

		<?php include('mods/modname.php'); ?>

		<script type="text/javascript">KISSY.use('page/init')</script>
	</body>
</html>