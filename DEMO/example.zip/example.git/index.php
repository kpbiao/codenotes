<?php

//处理参数
$path = isset($_GET['path']) ? $_GET['path'] : '';
$debug = isset($_GET['ks-debug']);
$publish = isset($_GET['publish']);

$DEMO_NAME = 'demo';//设定demo文件的目录名

if(!$path){//无路径参数显示列表
	
	$demo = './'.$DEMO_NAME;
	$arr_dir = array();
	$dir = opendir($demo);
	while ($path = readdir($dir)){
		$whole_path = $demo."/".$path;
		if(is_dir($whole_path) && substr($path,0,1) != '.'){
			$arr_dir[] = $path;
		}
	}
	closedir($dir);
	sort($arr_dir);
	//排序后遍历子目录
	echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Index Of Demo</title><style>body{margin:0 8px}dl{padding:10px;margin:0;}dt{background:url(http://gtms01.alicdn.com/tps/i1/T1QcXeFCJaXXaSQP_X-16-16.png) no-repeat scroll left center;padding-left:20px;height: 22px;line-height: 22px;margin-top: 8px;}dd{background:url(http://gtms01.alicdn.com/tps/i1/T16bXgFupdXXaSQP_X-16-16.png) no-repeat scroll left center;padding-left:20px;height: 20px;line-height: 20px;margin-left: 20px;}</style></head><body>';
	echo "<dl>";
	foreach ($arr_dir as $d) {
		echo "<dt>".$d."</dt>";//输出父级目录
		$arr_sub_dir = array();
		$tmp_path = $demo."/".$d;
		$sub_dir = opendir($tmp_path);
		while ($sub_path = readdir($sub_dir)){
			$whole_sub_path = $tmp_path."/".$sub_path;
			if(!is_dir($whole_sub_path) && substr($sub_path,0,1) != '.'){
				$arr_sub_dir[] = $sub_path;
			}
		}
		closedir($sub_dir);
		//排序后输出
		sort($arr_sub_dir);
		foreach ($arr_sub_dir as $file) {
			$ksdebug = $debug ? '&ks-debug' : '';
			echo '<dd><a href="?path='.$DEMO_NAME.'/'.$d.'/'.$file.$ksdebug.'">'.$file.'</a></dd>';
		}
	}
	echo "</dl>";
	echo '</body></html>';

}else{//转发并根据第二参数处理路径

	function transport($buffer){
		global $debug,$publish;
		$str = $buffer;

		if($publish){//发布状态页面不需要做替换
			return $str;
		}

		if($debug){//调试状态
			//处理css
			function replace_css($match){
				if(preg_match('/(.*)\?\?(.*)/', $match[1], $m)){
					$r = '';
					$css_list = explode(',', $m[2]);
					foreach ($css_list as $v) {
						$tmp = str_replace('-min', '', $v);
						$r .= '<link type="text/css" rel="stylesheet" href="'.$m[1].$tmp.'">';
					}
					return $r;
				}else{
					return str_replace('-min', '', $match[0]);
				}
			}
			$str = preg_replace_callback('/<link[^>]*href=\"([^\"]+)\"[^>]*>/',"replace_css",$str);
			//处理js
			function replace_js($match){
				if(preg_match('/(.*)\?\?(.*)/', $match[1], $m)){
					$r = '';
					$js_list = explode(',', $m[2]);
					foreach ($js_list as $v) {
						$tmp = str_replace('-min', '', $v);
						$r .= '<script src="'.$m[1].$tmp.'"></script>';
					}
					return $r;
				}else{
					return str_replace('-min', '', $match[0]);
				}
			}
			$str = preg_replace_callback('/<script[^>]*src=\"([^\"]+)\"[^>]*>.*<\/script>/',"replace_js",$str);

			$str = preg_replace("/(http|https):\/\/g.tbcdn.cn\/ebook\/[^\/'\"]+\/[^\/'\"]+/", './src', $str);
			$str = preg_replace("/\/\/g.tbcdn.cn\/ebook\/[^\/'\"]+\/[^\/'\"]+/", './src', $str);//额外处理无协议头的引用

		}else{//日常状态
			$str = str_replace("g.tbcdn.cn/ebook", "g.assets.daily.taobao.net/ebook", $str);
		}
		

		return $str;
	}
	ob_start("transport");
	include('./'.$path);
	ob_end_flush();

}