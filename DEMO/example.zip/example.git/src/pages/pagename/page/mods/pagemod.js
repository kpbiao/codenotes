KISSY.add(function(){
	
	return function(){
		console.log('i am pagemod');
	};

});