/**
 * @fileOverview Sample Util Mod
 * @author abc-team
 */
KISSY.add(function (S) {
    // 在 pages, widget, common  KISSY模块
    // 可以通过 requires 'utils/sample' 引入这个脚本
    return function(){
    	console.log('i am util');
    }
});