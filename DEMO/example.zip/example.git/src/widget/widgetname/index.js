/**
 * @fileOverview 
 * @author  
 */
KISSY.add(function (S) {

    var Widget = function(){
    	console.log('i am Widget')
    };

    return Widget;
    
}, { requires: [
    /* 可以直接引入utils中的模块
    'utils/js/mod'
    */
]});
